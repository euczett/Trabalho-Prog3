package vidafacil.dao;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Funções de leitura/escrita dos arquivos .txt (campos separados por ponto e vírgula). */
public class ArquivoUtil {

    public static Path caminho(String nomeArquivo) {
        return Paths.get(nomeArquivo);
    }

    public static List<String> lerLinhas(Path arquivo) {
        if (!Files.exists(arquivo)) {
            return Collections.emptyList();
        }
        try {
            return Files.readAllLines(arquivo, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("Erro ao ler " + arquivo, e);
        }
    }

    public static void escreverLinhas(Path arquivo, List<String> linhas) {
        try {
            Files.write(arquivo, linhas, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("Erro ao gravar " + arquivo, e);
        }
    }

    /** Protege ; \ e quebras de linha para o texto caber em uma única linha do arquivo. */
    public static String escapar(String texto) {
        StringBuilder sb = new StringBuilder();
        for (char c : texto.toCharArray()) {
            switch (c) {
                case '\\': sb.append("\\\\"); break;
                case ';':  sb.append("\\p");  break;
                case '\n': sb.append("\\n");  break;
                case '\r': break;
                default:   sb.append(c);
            }
        }
        return sb.toString();
    }

    /** Divide uma linha do arquivo em campos, desfazendo o escape. */
    public static String[] separar(String linha) {
        List<String> campos = new ArrayList<>();
        StringBuilder atual = new StringBuilder();
        for (int i = 0; i < linha.length(); i++) {
            char c = linha.charAt(i);
            if (c == '\\' && i + 1 < linha.length()) {
                char prox = linha.charAt(++i);
                if (prox == 'p') atual.append(';');
                else if (prox == 'n') atual.append('\n');
                else atual.append(prox);
            } else if (c == ';') {
                campos.add(atual.toString());
                atual.setLength(0);
            } else {
                atual.append(c);
            }
        }
        campos.add(atual.toString());
        return campos.toArray(new String[0]);
    }
}
