package vidafacil.dao;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import vidafacil.model.Tarefa;

/** Guarda as tarefas em tarefas.txt  ->  id;usuario;titulo;descricao;status */
public class TarefaDAO {

    private final Path arquivo = ArquivoUtil.caminho("tarefas.txt");

    private List<Tarefa> listarTodas() {
        List<Tarefa> lista = new ArrayList<>();
        for (String linha : ArquivoUtil.lerLinhas(arquivo)) {
            if (linha.isBlank()) continue;
            String[] c = ArquivoUtil.separar(linha);
            if (c.length >= 5) {
                lista.add(new Tarefa(Integer.parseInt(c[0]), c[1], c[2], c[3], c[4]));
            }
        }
        return lista;
    }

    private void gravarTodas(List<Tarefa> tarefas) {
        List<String> linhas = new ArrayList<>();
        for (Tarefa t : tarefas) {
            linhas.add(t.getId() + ";" + ArquivoUtil.escapar(t.getUsuario()) + ";"
                    + ArquivoUtil.escapar(t.getTitulo()) + ";"
                    + ArquivoUtil.escapar(t.getDescricao()) + ";"
                    + ArquivoUtil.escapar(t.getStatus()));
        }
        ArquivoUtil.escreverLinhas(arquivo, linhas);
    }

    public List<Tarefa> listar(String usuario) {
        List<Tarefa> lista = new ArrayList<>();
        for (Tarefa t : listarTodas()) {
            if (t.getUsuario().equalsIgnoreCase(usuario)) lista.add(t);
        }
        return lista;
    }

    /** ID automático: maior ID existente + 1. */
    public int proximoId() {
        int maior = 0;
        for (Tarefa t : listarTodas()) {
            if (t.getId() > maior) maior = t.getId();
        }
        return maior + 1;
    }

    /** Se o ID já existe, atualiza; senão, adiciona no fim. */
    public void salvar(Tarefa nova) {
        List<Tarefa> todas = listarTodas();
        boolean achou = false;
        for (int i = 0; i < todas.size(); i++) {
            if (todas.get(i).getId() == nova.getId()) {
                todas.set(i, nova);
                achou = true;
                break;
            }
        }
        if (!achou) todas.add(nova);
        gravarTodas(todas);
    }

    public void excluir(int id) {
        List<Tarefa> todas = listarTodas();
        todas.removeIf(t -> t.getId() == id);
        gravarTodas(todas);
    }
}
