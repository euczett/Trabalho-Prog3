package vidafacil.dao;

import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import vidafacil.model.Usuario;

/** Guarda os usuários em usuarios.txt  ->  nome;login;senhaHash */
public class UsuarioDAO {

    private final Path arquivo = ArquivoUtil.caminho("usuarios.txt");

    private List<Usuario> listar() {
        List<Usuario> lista = new ArrayList<>();
        for (String linha : ArquivoUtil.lerLinhas(arquivo)) {
            if (linha.isBlank()) continue;
            String[] c = ArquivoUtil.separar(linha);
            if (c.length >= 3) {
                lista.add(new Usuario(c[0], c[1], c[2]));
            }
        }
        return lista;
    }

    public boolean existe(String login) {
        for (Usuario u : listar()) {
            if (u.getLogin().equalsIgnoreCase(login)) return true;
        }
        return false;
    }

    public void cadastrar(String nome, String login, String senha) {
        List<String> linhas = new ArrayList<>(ArquivoUtil.lerLinhas(arquivo));
        linhas.add(ArquivoUtil.escapar(nome) + ";" + ArquivoUtil.escapar(login) + ";" + hash(senha));
        ArquivoUtil.escreverLinhas(arquivo, linhas);
    }

    /** Retorna o usuário se login e senha conferem; caso contrário, null. */
    public Usuario autenticar(String login, String senha) {
        String h = hash(senha);
        for (Usuario u : listar()) {
            if (u.getLogin().equalsIgnoreCase(login) && u.getSenhaHash().equals(h)) {
                return u;
            }
        }
        return null;
    }

    private static String hash(String senha) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(senha.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
