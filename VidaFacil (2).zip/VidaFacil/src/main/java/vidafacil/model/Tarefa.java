package vidafacil.model;

public class Tarefa {

    public static final String PENDENTE = "Pendente";
    public static final String CONCLUIDA = "Concluída";

    private int id;
    private String usuario;   // login do dono da tarefa
    private String titulo;
    private String descricao;
    private String status;

    public Tarefa(int id, String usuario, String titulo, String descricao, String status) {
        this.id = id;
        this.usuario = usuario;
        this.titulo = titulo;
        this.descricao = descricao;
        this.status = status;
    }

    public int getId() { return id; }
    public String getUsuario() { return usuario; }
    public String getTitulo() { return titulo; }
    public String getDescricao() { return descricao; }
    public String getStatus() { return status; }

    public void setTitulo(String titulo) { this.titulo = titulo; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public void setStatus(String status) { this.status = status; }
}
