package vidafacil.model;

public class Usuario {

    private final String nome;
    private final String login;
    private final String senhaHash;

    public Usuario(String nome, String login, String senhaHash) {
        this.nome = nome;
        this.login = login;
        this.senhaHash = senhaHash;
    }

    public String getNome() { return nome; }
    public String getLogin() { return login; }
    public String getSenhaHash() { return senhaHash; }
}
