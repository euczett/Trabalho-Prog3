package vidafacil.view;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/** Cores e componentes visuais compartilhados entre as telas. */
public class Estilo {

    public static final Color FUNDO_LATERAL = new Color(50, 53, 66);
    public static final Color FUNDO_CONTEUDO = new Color(217, 217, 224);
    public static final Color BOTAO = new Color(157, 183, 219);

    public static JButton botao(String texto) {
        JButton b = new JButton(texto);
        b.setBackground(BOTAO);
        b.setFont(new Font("Serif", Font.BOLD, 13));
        b.setFocusPainted(false);
        return b;
    }

    public static JLabel rotulo(String texto, int x, int y, int largura) {
        JLabel l = new JLabel(texto, SwingConstants.RIGHT);
        l.setBounds(x, y, largura, 22);
        return l;
    }

    /** Barra lateral escura com título, subtítulo e os botões informados. */
    public static JPanel barraLateral(String subtitulo, JComponent... itens) {
        JPanel p = new JPanel();
        p.setBackground(FUNDO_LATERAL);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setPreferredSize(new Dimension(200, 0));
        p.setBorder(BorderFactory.createEmptyBorder(60, 10, 40, 10));

        JLabel titulo = new JLabel("Vida+Fácil");
        titulo.setFont(new Font("Serif", Font.BOLD, 22));
        titulo.setForeground(Color.WHITE);
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(titulo);
        p.add(Box.createVerticalStrut(15));

        for (String linha : subtitulo.split("\n")) {
            JLabel l = new JLabel(linha);
            l.setForeground(Color.WHITE);
            l.setFont(new Font("SansSerif", Font.PLAIN, 11));
            l.setAlignmentX(Component.CENTER_ALIGNMENT);
            p.add(l);
        }
        p.add(Box.createVerticalStrut(40));

        for (JComponent c : itens) {
            c.setAlignmentX(Component.CENTER_ALIGNMENT);
            c.setMaximumSize(new Dimension(110, 36));
            p.add(c);
            p.add(Box.createVerticalStrut(50));
        }
        return p;
    }
}
