package vidafacil.view;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import vidafacil.dao.UsuarioDAO;
import vidafacil.model.Usuario;

/** Tela inicial: barra lateral com Login/Cadastro e formulário correspondente à direita. */
public class TelaAutenticacao extends JFrame {

    private static final String CARD_LOGIN = "login";
    private static final String CARD_CADASTRO = "cadastro";

    private final UsuarioDAO usuarioDAO = new UsuarioDAO();
    private final CardLayout cards = new CardLayout();
    private final JPanel conteudo = new JPanel(cards);

    private final JTextField txtLogin = new JTextField();
    private final JPasswordField txtSenha = new JPasswordField();

    private final JTextField txtNome = new JTextField();
    private final JTextField txtNovoLogin = new JTextField();
    private final JPasswordField txtNovaSenha = new JPasswordField();
    private final JPasswordField txtConfirma = new JPasswordField();

    public TelaAutenticacao() {
        super("Vida+Fácil");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 520);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JButton btnIrLogin = Estilo.botao("Login");
        JButton btnIrCadastro = Estilo.botao("Cadastro");
        btnIrLogin.addActionListener(e -> cards.show(conteudo, CARD_LOGIN));
        btnIrCadastro.addActionListener(e -> cards.show(conteudo, CARD_CADASTRO));

        add(Estilo.barraLateral("Sua vida\nMuito mais organizada", btnIrLogin, btnIrCadastro), BorderLayout.WEST);

        conteudo.add(criarPainelLogin(), CARD_LOGIN);
        conteudo.add(criarPainelCadastro(), CARD_CADASTRO);
        add(conteudo, BorderLayout.CENTER);
    }

    private JPanel criarPainelLogin() {
        JPanel p = new JPanel(null);
        p.setBackground(Estilo.FUNDO_CONTEUDO);

        p.add(Estilo.rotulo("Login:", 160, 150, 70));
        txtLogin.setBounds(240, 150, 260, 26);
        p.add(txtLogin);

        p.add(Estilo.rotulo("Senha:", 160, 200, 70));
        txtSenha.setBounds(240, 200, 260, 26);
        p.add(txtSenha);

        JButton entrar = new JButton("Entrar");
        entrar.setBounds(240, 260, 110, 32);
        entrar.addActionListener(e -> entrar());
        p.add(entrar);

        txtSenha.addActionListener(e -> entrar());
        return p;
    }

    private JPanel criarPainelCadastro() {
        JPanel p = new JPanel(null);
        p.setBackground(Estilo.FUNDO_CONTEUDO);

        p.add(Estilo.rotulo("Nome:", 120, 100, 110));
        txtNome.setBounds(240, 100, 260, 26);
        p.add(txtNome);

        p.add(Estilo.rotulo("Login:", 120, 150, 110));
        txtNovoLogin.setBounds(240, 150, 260, 26);
        p.add(txtNovoLogin);

        p.add(Estilo.rotulo("Senha:", 120, 200, 110));
        txtNovaSenha.setBounds(240, 200, 260, 26);
        p.add(txtNovaSenha);

        p.add(Estilo.rotulo("Confirmar senha:", 120, 250, 110));
        txtConfirma.setBounds(240, 250, 260, 26);
        p.add(txtConfirma);

        JButton cadastrar = new JButton("Cadastrar");
        cadastrar.setBounds(240, 310, 110, 32);
        cadastrar.addActionListener(e -> cadastrar());
        p.add(cadastrar);
        return p;
    }

    private void entrar() {
        String login = txtLogin.getText().trim();
        String senha = new String(txtSenha.getPassword());
        if (login.isEmpty() || senha.isEmpty()) {
            aviso("Informe login e senha.");
            return;
        }
        Usuario u = usuarioDAO.autenticar(login, senha);
        if (u == null) {
            aviso("Login ou senha incorretos.");
            return;
        }
        new TelaTarefas(u).setVisible(true);
        dispose();
    }

    private void cadastrar() {
        String nome = txtNome.getText().trim();
        String login = txtNovoLogin.getText().trim();
        String senha = new String(txtNovaSenha.getPassword());
        String confirma = new String(txtConfirma.getPassword());

        if (nome.isEmpty() || login.isEmpty() || senha.isEmpty()) {
            aviso("Preencha todos os campos.");
            return;
        }
        if (!senha.equals(confirma)) {
            aviso("As senhas não conferem.");
            return;
        }
        if (usuarioDAO.existe(login)) {
            aviso("Esse login já está em uso.");
            return;
        }
        usuarioDAO.cadastrar(nome, login, senha);
        JOptionPane.showMessageDialog(this, "Cadastro realizado! Faça o login.");

        txtNome.setText("");
        txtNovoLogin.setText("");
        txtNovaSenha.setText("");
        txtConfirma.setText("");
        txtLogin.setText(login);
        txtSenha.setText("");
        cards.show(conteudo, CARD_LOGIN);
    }

    private void aviso(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Atenção", JOptionPane.WARNING_MESSAGE);
    }
}
