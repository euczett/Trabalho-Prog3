package vidafacil.view;

import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import vidafacil.dao.TarefaDAO;
import vidafacil.model.Tarefa;
import vidafacil.model.Usuario;

/** Tela principal: formulário de tarefa à esquerda e lista à direita (clique para editar). */
public class TelaTarefas extends JFrame {

    private final Usuario usuario;
    private final TarefaDAO dao = new TarefaDAO();
    private List<Tarefa> tarefas = new ArrayList<>();

    private final JTextField txtId = new JTextField();
    private final JTextField txtTitulo = new JTextField();
    private final JTextArea txtDescricao = new JTextArea();
    private final JComboBox<String> cbStatus =
            new JComboBox<>(new String[]{Tarefa.PENDENTE, Tarefa.CONCLUIDA});
    private final JButton btnSalvar = new JButton("Cadastrar");
    private final JButton btnExcluir = new JButton("Excluir");
    private final JButton btnNovo = new JButton("Novo");

    private final DefaultTableModel modelo = new DefaultTableModel(
            new Object[]{"ID", "Título", "Descrição", "Status"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable tabela = new JTable(modelo);

    public TelaTarefas(Usuario usuario) {
        super("Vida+Fácil - " + usuario.getNome());
        this.usuario = usuario;

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 520);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JButton btnSair = Estilo.botao("Sair");
        btnSair.addActionListener(e -> {
            new TelaAutenticacao().setVisible(true);
            dispose();
        });
        add(Estilo.barraLateral("Olá, " + usuario.getNome(), btnSair), BorderLayout.WEST);
        add(criarPainelFormulario(), BorderLayout.CENTER);

        atualizarLista();
        limparFormulario();
    }

    private JPanel criarPainelFormulario() {
        JPanel p = new JPanel(null);
        p.setBackground(Estilo.FUNDO_CONTEUDO);

        p.add(Estilo.rotulo("ID Tarefa:", 10, 40, 80));
        txtId.setBounds(100, 40, 260, 26);
        txtId.setEditable(false);   // ID automático
        p.add(txtId);

        p.add(Estilo.rotulo("Título:", 10, 90, 80));
        txtTitulo.setBounds(100, 90, 260, 26);
        p.add(txtTitulo);

        p.add(Estilo.rotulo("Descrição:", 10, 140, 80));
        txtDescricao.setLineWrap(true);
        txtDescricao.setWrapStyleWord(true);
        JScrollPane spDescricao = new JScrollPane(txtDescricao);
        spDescricao.setBounds(100, 140, 260, 90);
        p.add(spDescricao);

        p.add(Estilo.rotulo("Concluída:", 10, 260, 80));
        cbStatus.setBounds(100, 260, 260, 26);
        p.add(cbStatus);

        btnSalvar.setBounds(100, 330, 120, 32);
        btnSalvar.addActionListener(e -> salvar());
        p.add(btnSalvar);

        btnExcluir.setBounds(230, 330, 130, 32);
        btnExcluir.addActionListener(e -> excluir());
        p.add(btnExcluir);

        btnNovo.setBounds(100, 375, 120, 32);
        btnNovo.addActionListener(e -> limparFormulario());
        p.add(btnNovo);

        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.getColumnModel().getColumn(0).setMaxWidth(40);
        tabela.getColumnModel().getColumn(3).setMaxWidth(90);
        tabela.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabela.getSelectedRow() >= 0) {
                carregarParaEdicao(tarefas.get(tabela.getSelectedRow()));
            }
        });
        JScrollPane spTabela = new JScrollPane(tabela);
        spTabela.setBounds(380, 40, 300, 380);
        p.add(spTabela);

        return p;
    }

    private void atualizarLista() {
        tarefas = dao.listar(usuario.getLogin());
        modelo.setRowCount(0);
        for (Tarefa t : tarefas) {
            modelo.addRow(new Object[]{t.getId(), t.getTitulo(), t.getDescricao(), t.getStatus()});
        }
    }

    private void limparFormulario() {
        tabela.clearSelection();
        txtId.setText(String.valueOf(dao.proximoId()));
        txtTitulo.setText("");
        txtDescricao.setText("");
        cbStatus.setSelectedIndex(0);
        btnSalvar.setText("Cadastrar");
        btnExcluir.setEnabled(false);
        txtTitulo.requestFocus();
    }

    private void carregarParaEdicao(Tarefa t) {
        txtId.setText(String.valueOf(t.getId()));
        txtTitulo.setText(t.getTitulo());
        txtDescricao.setText(t.getDescricao());
        cbStatus.setSelectedItem(t.getStatus());
        btnSalvar.setText("Salvar");
        btnExcluir.setEnabled(true);
    }

    private void salvar() {
        String titulo = txtTitulo.getText().trim();
        if (titulo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe o título da tarefa.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Tarefa t = new Tarefa(
                Integer.parseInt(txtId.getText()),
                usuario.getLogin(),
                titulo,
                txtDescricao.getText().trim(),
                (String) cbStatus.getSelectedItem());
        dao.salvar(t);
        atualizarLista();
        limparFormulario();
    }

    private void excluir() {
        int op = JOptionPane.showConfirmDialog(this, "Excluir esta tarefa?",
                "Confirmar", JOptionPane.YES_NO_OPTION);
        if (op == JOptionPane.YES_OPTION) {
            dao.excluir(Integer.parseInt(txtId.getText()));
            atualizarLista();
            limparFormulario();
        }
    }
}
