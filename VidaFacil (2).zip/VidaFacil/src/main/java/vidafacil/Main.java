package vidafacil;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import vidafacil.view.TelaAutenticacao;

public class Main {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ignorado) {
        }
        SwingUtilities.invokeLater(() -> new TelaAutenticacao().setVisible(true));
    }
}
